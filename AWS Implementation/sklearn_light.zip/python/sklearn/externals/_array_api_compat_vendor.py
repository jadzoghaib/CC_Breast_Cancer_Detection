# DO NOT RENAME THIS FILE
# This is a hook for array_api_extra/_lib/_compat.py
# to co-vendor array_api_compat and potentially override its functions.

from .array_api_compat import *  # noqa: F403
